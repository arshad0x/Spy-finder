package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.NumberLookupScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VehicleLookupScreen
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val isUnlocked by viewModel.isUnlocked.collectAsStateWithLifecycle()
    val unlockError by viewModel.unlockError.collectAsStateWithLifecycle()

    if (!isUnlocked) {
        LockScreen(
            errorMessage = unlockError,
            onUnlock = { pwd -> viewModel.unlockApp(pwd) },
            onPasswordChanged = { viewModel.clearUnlockError() }
        )
        return
    }

    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val viewMode by viewModel.viewMode.collectAsStateWithLifecycle()

    val numberInput by viewModel.numberInput.collectAsStateWithLifecycle()
    val isNumberLoading by viewModel.isNumberLoading.collectAsStateWithLifecycle()
    val numberResult by viewModel.numberResult.collectAsStateWithLifecycle()

    val vehicleInput by viewModel.vehicleInput.collectAsStateWithLifecycle()
    val isVehicleLoading by viewModel.isVehicleLoading.collectAsStateWithLifecycle()
    val vehicleResult by viewModel.vehicleResult.collectAsStateWithLifecycle()

    val historyList by viewModel.historyList.collectAsStateWithLifecycle()
    val historySearchQuery by viewModel.historySearchQuery.collectAsStateWithLifecycle()
    val historyTypeFilter by viewModel.historyTypeFilter.collectAsStateWithLifecycle()

    val apiConfig by viewModel.apiConfig.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationTabItem(
                    title = "Number",
                    selectedIcon = Icons.Filled.Phone,
                    unselectedIcon = Icons.Outlined.Phone,
                    isSelected = currentTab == AppTab.NUMBER,
                    activeColor = CyberCyan,
                    onClick = { viewModel.setTab(AppTab.NUMBER) },
                    testTag = "tab_number"
                )
                NavigationTabItem(
                    title = "Vehicle",
                    selectedIcon = Icons.Filled.DirectionsCar,
                    unselectedIcon = Icons.Outlined.DirectionsCar,
                    isSelected = currentTab == AppTab.VEHICLE,
                    activeColor = AmberGlow,
                    onClick = { viewModel.setTab(AppTab.VEHICLE) },
                    testTag = "tab_vehicle"
                )
                NavigationTabItem(
                    title = "History",
                    selectedIcon = Icons.Filled.History,
                    unselectedIcon = Icons.Outlined.History,
                    isSelected = currentTab == AppTab.HISTORY,
                    activeColor = ElectricBlue,
                    onClick = { viewModel.setTab(AppTab.HISTORY) },
                    testTag = "tab_history"
                )
                NavigationTabItem(
                    title = "API & HTML",
                    selectedIcon = Icons.Filled.Settings,
                    unselectedIcon = Icons.Outlined.Settings,
                    isSelected = currentTab == AppTab.SETTINGS,
                    activeColor = CyberCyan,
                    onClick = { viewModel.setTab(AppTab.SETTINGS) },
                    testTag = "tab_settings"
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { tab ->
                when (tab) {
                    AppTab.NUMBER -> {
                        NumberLookupScreen(
                            numberInput = numberInput,
                            isLoading = isNumberLoading,
                            result = numberResult,
                            viewMode = viewMode,
                            onInputChange = viewModel::onNumberInputChange,
                            onSearch = { target -> viewModel.searchNumber(target) },
                            onViewModeChange = viewModel::setViewMode,
                            onCopy = viewModel::copyToClipboard,
                            onShare = viewModel::shareContent,
                            onLockApp = viewModel::lockApp
                        )
                    }
                    AppTab.VEHICLE -> {
                        VehicleLookupScreen(
                            vehicleInput = vehicleInput,
                            isLoading = isVehicleLoading,
                            result = vehicleResult,
                            viewMode = viewMode,
                            onInputChange = viewModel::onVehicleInputChange,
                            onSearch = { target -> viewModel.searchVehicle(target) },
                            onViewModeChange = viewModel::setViewMode,
                            onCopy = viewModel::copyToClipboard,
                            onShare = viewModel::shareContent,
                            onLockApp = viewModel::lockApp
                        )
                    }
                    AppTab.HISTORY -> {
                        HistoryScreen(
                            historyList = historyList,
                            searchQuery = historySearchQuery,
                            typeFilter = historyTypeFilter,
                            onSearchQueryChange = viewModel::setHistorySearchQuery,
                            onTypeFilterChange = viewModel::setHistoryTypeFilter,
                            onSelectHistoryItem = viewModel::loadHistoryItem,
                            onDeleteHistoryItem = viewModel::deleteHistoryItem,
                            onClearAllHistory = viewModel::clearAllHistory
                        )
                    }
                    AppTab.SETTINGS -> {
                        SettingsScreen(
                            currentConfig = apiConfig,
                            onSaveConfig = viewModel::saveApiConfig,
                            onResetConfig = viewModel::resetApiConfig,
                            onCopy = viewModel::copyToClipboard,
                            onShare = viewModel::shareContent,
                            onLockApp = viewModel::lockApp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavigationTabItem(
    title: String,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    isSelected: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    NavigationBarItem(
        selected = isSelected,
        onClick = onClick,
        icon = {
            Icon(
                imageVector = if (isSelected) selectedIcon else unselectedIcon,
                contentDescription = title,
                modifier = Modifier.size(24.dp)
            )
        },
        label = {
            Text(
                text = title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.Black,
            selectedTextColor = activeColor,
            indicatorColor = activeColor,
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = Modifier.testTag(testTag)
    )
}
