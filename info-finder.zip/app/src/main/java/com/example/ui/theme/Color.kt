package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF2979FF)
val NeonEmerald = Color(0xFF00E676)
val AmberGlow = Color(0xFFFFAB00)
val DarkNavyBg = Color(0xFF0A0E1A)
val SurfaceDark = Color(0xFF131B2E)
val CardDark = Color(0xFF1A243B)
val BorderDark = Color(0xFF293859)
val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val AccentPurple = Color(0xFF7C4DFF)

// Light theme colors
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

