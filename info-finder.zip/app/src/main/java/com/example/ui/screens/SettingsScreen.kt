package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApiConfig
import com.example.data.model.DEFAULT_HTML_TEMPLATE
import com.example.data.model.LookupResult
import com.example.data.model.LookupType
import com.example.ui.components.HtmlWebViewComponent
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonEmerald
import com.example.util.HtmlTemplateEngine

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    currentConfig: ApiConfig,
    onSaveConfig: (ApiConfig) -> Unit,
    onResetConfig: () -> Unit,
    onCopy: (String, String) -> Unit,
    onShare: (String, String) -> Unit,
    onLockApp: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var numApiUrl by remember(currentConfig) { mutableStateOf(currentConfig.numberApiUrl) }
    var numApiKey by remember(currentConfig) { mutableStateOf(currentConfig.numberApiKey) }
    var numParamName by remember(currentConfig) { mutableStateOf(currentConfig.numberParamName) }

    var vehApiUrl by remember(currentConfig) { mutableStateOf(currentConfig.vehicleApiUrl) }
    var vehApiKey by remember(currentConfig) { mutableStateOf(currentConfig.vehicleApiKey) }
    var vehParamName by remember(currentConfig) { mutableStateOf(currentConfig.vehicleParamName) }

    var htmlTemplate by remember(currentConfig) { mutableStateOf(currentConfig.customHtmlTemplate) }
    var showPreviewDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "API & HTML Settings",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Update API endpoints, API keys & customize HTML design",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = { onResetConfig() },
                modifier = Modifier.testTag("reset_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = "Reset to Default",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Section 1: Number API Config
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Http,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NUMBER LOOKUP API",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )
                }

                OutlinedTextField(
                    value = numApiUrl,
                    onValueChange = { numApiUrl = it },
                    label = { Text("Number API URL") },
                    placeholder = { Text("https://anon-num-info.vercel.app/num") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("number_api_url_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = numApiKey,
                        onValueChange = { numApiKey = it },
                        label = { Text("API Key") },
                        placeholder = { Text("temp2808num") },
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("number_api_key_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        )
                    )

                    OutlinedTextField(
                        value = numParamName,
                        onValueChange = { numParamName = it },
                        label = { Text("Param Name") },
                        placeholder = { Text("num") },
                        modifier = Modifier
                            .weight(0.7f)
                            .testTag("number_param_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }
            }
        }

        // Section 2: Vehicle API Config
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "VEHICLE LOOKUP API",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }

                OutlinedTextField(
                    value = vehApiUrl,
                    onValueChange = { vehApiUrl = it },
                    label = { Text("Vehicle API URL") },
                    placeholder = { Text("https://anon-num-info.vercel.app/num") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vehicle_api_url_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = vehApiKey,
                        onValueChange = { vehApiKey = it },
                        label = { Text("API Key") },
                        placeholder = { Text("temp2808num") },
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("vehicle_api_key_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        )
                    )

                    OutlinedTextField(
                        value = vehParamName,
                        onValueChange = { vehParamName = it },
                        label = { Text("Param Name") },
                        placeholder = { Text("num") },
                        modifier = Modifier
                            .weight(0.7f)
                            .testTag("vehicle_param_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }
            }
        }

        // Section 3: HTML Template Editor
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = NeonEmerald,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CUSTOM HTML TEMPLATE",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = NeonEmerald
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { showPreviewDialog = true },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Preview", fontSize = 12.sp)
                        }
                    }
                }

                Text(
                    text = "You can update the HTML structure below. Available variables:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Placeholder tokens chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("{{QUERY}}", "{{TYPE}}", "{{DATE}}", "{{STATUS}}", "{{DATA_ITEMS}}", "{{RAW_JSON}}").forEach { token ->
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable {
                                    htmlTemplate += " $token"
                                },
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.background
                        ) {
                            Text(
                                text = token,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyberCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = htmlTemplate,
                    onValueChange = { htmlTemplate = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .testTag("html_template_editor"),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonEmerald,
                        focusedContainerColor = Color(0xFF080E1A),
                        unfocusedContainerColor = Color(0xFF080E1A),
                        focusedTextColor = Color(0xFF86EFAC),
                        unfocusedTextColor = Color(0xFF86EFAC)
                    )
                )
            }
        }

        // Section 4: App Lock & Security
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "APP SECURITY & LOCK",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = NeonEmerald.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = NeonEmerald,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Text(
                    text = "App access is password-protected. To lock the application immediately and prevent unauthorized access, click below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedButton(
                    onClick = onLockApp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_lock_app_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("LOCK APP NOW", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Action Buttons: Save & Reset
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    numApiUrl = "https://anon-num-info.vercel.app/num"
                    numApiKey = "temp2808num"
                    numParamName = "num"
                    vehApiUrl = "https://anon-num-info.vercel.app/num"
                    vehApiKey = "temp2808num"
                    vehParamName = "num"
                    htmlTemplate = DEFAULT_HTML_TEMPLATE
                    onResetConfig()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RESET")
            }

            Button(
                onClick = {
                    val updated = ApiConfig(
                        numberApiUrl = numApiUrl.trim(),
                        numberApiKey = numApiKey.trim(),
                        numberParamName = numParamName.trim(),
                        vehicleApiUrl = vehApiUrl.trim(),
                        vehicleApiKey = vehApiKey.trim(),
                        vehicleParamName = vehParamName.trim(),
                        customHtmlTemplate = htmlTemplate
                    )
                    onSaveConfig(updated)
                },
                modifier = Modifier
                    .weight(1.5f)
                    .height(50.dp)
                    .testTag("save_settings_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyan,
                    contentColor = Color.Black
                )
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("SAVE SETTINGS", fontWeight = FontWeight.Bold)
            }
        }
    }

    // HTML Preview Dialog
    if (showPreviewDialog) {
        val sampleResult = LookupResult(
            query = "9876543210",
            type = LookupType.NUMBER,
            isSuccess = true,
            statusCode = 200,
            rawResponse = """{"status":"success","mobile":"9876543210","name":"Sample User","operator":"Airtel","circle":"Delhi NCR"}""",
            parsedData = mapOf(
                "mobile" to "9876543210",
                "name" to "Sample User",
                "operator" to "Airtel",
                "circle" to "Delhi NCR",
                "status" to "Active"
            )
        )
        val renderedPreview = HtmlTemplateEngine.renderHtml(sampleResult, htmlTemplate)

        AlertDialog(
            onDismissRequest = { showPreviewDialog = false },
            title = { Text("Template Live Preview") },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                ) {
                    HtmlWebViewComponent(
                        htmlContent = renderedPreview,
                        onCopyHtml = { onCopy(renderedPreview, "Rendered HTML Preview") },
                        onShareHtml = { onShare(renderedPreview, "Sample Preview") }
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showPreviewDialog = false }) {
                    Text("Close Preview")
                }
            }
        )
    }
}
