package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.InfoApiService
import com.example.data.db.AppDatabase
import com.example.data.db.HistoryEntity
import com.example.data.model.ApiConfig
import com.example.data.model.LookupResult
import com.example.data.model.LookupType
import com.example.data.repository.SettingsRepository
import com.example.util.HtmlTemplateEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class AppTab(val title: String) {
    NUMBER("Number Info"),
    VEHICLE("Vehicle Info"),
    HISTORY("History"),
    SETTINGS("API & HTML")
}

enum class ViewMode {
    CARDS,
    HTML,
    RAW_JSON
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val apiService = InfoApiService()
    private val database = AppDatabase.getDatabase(application)
    private val historyDao = database.historyDao()
    private val settingsRepo = SettingsRepository(application)

    // App Lock State (Default Locked)
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _unlockError = MutableStateFlow<String?>(null)
    val unlockError: StateFlow<String?> = _unlockError.asStateFlow()

    // Current Navigation Tab
    private val _currentTab = MutableStateFlow(AppTab.NUMBER)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    // View Mode for Result (Cards vs HTML Preview vs Raw JSON)
    private val _viewMode = MutableStateFlow(ViewMode.CARDS)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    // Inputs
    private val _numberInput = MutableStateFlow("")
    val numberInput: StateFlow<String> = _numberInput.asStateFlow()

    private val _vehicleInput = MutableStateFlow("")
    val vehicleInput: StateFlow<String> = _vehicleInput.asStateFlow()

    // Loading & Results
    private val _isNumberLoading = MutableStateFlow(false)
    val isNumberLoading: StateFlow<Boolean> = _isNumberLoading.asStateFlow()

    private val _numberResult = MutableStateFlow<LookupResult?>(null)
    val numberResult: StateFlow<LookupResult?> = _numberResult.asStateFlow()

    private val _isVehicleLoading = MutableStateFlow(false)
    val isVehicleLoading: StateFlow<Boolean> = _isVehicleLoading.asStateFlow()

    private val _vehicleResult = MutableStateFlow<LookupResult?>(null)
    val vehicleResult: StateFlow<LookupResult?> = _vehicleResult.asStateFlow()

    // Settings
    val apiConfig: StateFlow<ApiConfig> = settingsRepo.configFlow

    // History Search
    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyTypeFilter = MutableStateFlow<String?>(null)
    val historyTypeFilter: StateFlow<String?> = _historyTypeFilter.asStateFlow()

    val historyList: StateFlow<List<HistoryEntity>> = combine(
        historyDao.getAllHistory(),
        _historySearchQuery,
        _historyTypeFilter
    ) { list, query, filter ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.query.contains(query, ignoreCase = true) ||
                    item.summaryTitle.contains(query, ignoreCase = true) ||
                    item.rawResponse.contains(query, ignoreCase = true)
            val matchesFilter = filter == null || item.type.equals(filter, ignoreCase = true)
            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun onNumberInputChange(value: String) {
        _numberInput.value = value
    }

    fun onVehicleInputChange(value: String) {
        _vehicleInput.value = value
    }

    fun searchNumber(targetNumber: String? = null) {
        val query = (targetNumber ?: _numberInput.value).trim()
        if (query.isBlank()) {
            Toast.makeText(getApplication(), "Please enter a mobile/phone number", Toast.LENGTH_SHORT).show()
            return
        }
        _numberInput.value = query

        viewModelScope.launch {
            _isNumberLoading.value = true
            try {
                val result = apiService.performLookup(LookupType.NUMBER, query, apiConfig.value)
                _numberResult.value = result

                // Save to history
                saveHistoryItem(result)
            } finally {
                _isNumberLoading.value = false
            }
        }
    }

    fun searchVehicle(targetRc: String? = null) {
        val query = (targetRc ?: _vehicleInput.value).trim().uppercase()
        if (query.isBlank()) {
            Toast.makeText(getApplication(), "Please enter a vehicle registration number", Toast.LENGTH_SHORT).show()
            return
        }
        _vehicleInput.value = query

        viewModelScope.launch {
            _isVehicleLoading.value = true
            try {
                val result = apiService.performLookup(LookupType.VEHICLE, query, apiConfig.value)
                _vehicleResult.value = result

                // Save to history
                saveHistoryItem(result)
            } finally {
                _isVehicleLoading.value = false
            }
        }
    }

    private suspend fun saveHistoryItem(result: LookupResult) {
        val title = if (result.parsedData.isNotEmpty()) {
            result.parsedData["name"]
                ?: result.parsedData["owner_name"]
                ?: result.parsedData["operator"]
                ?: result.parsedData.values.firstOrNull()
                ?: "${result.type.displayName} Lookup"
        } else {
            if (result.isSuccess) "Lookup Response" else "Lookup Failed"
        }

        val jsonMap = JSONObject(result.parsedData).toString()

        val historyEntity = HistoryEntity(
            type = result.type.name,
            query = result.query,
            isSuccess = result.isSuccess,
            statusCode = result.statusCode,
            summaryTitle = title,
            rawResponse = result.rawResponse,
            parsedDataJson = jsonMap,
            timestamp = result.timestamp
        )
        historyDao.insertHistory(historyEntity)
    }

    fun loadHistoryItem(item: HistoryEntity) {
        val type = try {
            LookupType.valueOf(item.type)
        } catch (_: Exception) {
            LookupType.NUMBER
        }

        val parsedMap = mutableMapOf<String, String>()
        try {
            val jsonObject = JSONObject(item.parsedDataJson)
            val keys = jsonObject.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                parsedMap[key] = jsonObject.optString(key)
            }
        } catch (_: Exception) {
            // fallback
        }

        val result = LookupResult(
            query = item.query,
            type = type,
            isSuccess = item.isSuccess,
            statusCode = item.statusCode,
            rawResponse = item.rawResponse,
            parsedData = parsedMap,
            timestamp = item.timestamp,
            errorMessage = if (!item.isSuccess) "Saved error record" else null
        )
        val html = HtmlTemplateEngine.renderHtml(result, apiConfig.value.customHtmlTemplate)
        val fullResult = result.copy(generatedHtml = html)

        if (type == LookupType.NUMBER) {
            _numberInput.value = item.query
            _numberResult.value = fullResult
            _currentTab.value = AppTab.NUMBER
        } else {
            _vehicleInput.value = item.query
            _vehicleResult.value = fullResult
            _currentTab.value = AppTab.VEHICLE
        }
    }

    fun deleteHistoryItem(item: HistoryEntity) {
        viewModelScope.launch {
            historyDao.deleteHistory(item)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyDao.clearAll()
            Toast.makeText(getApplication(), "History cleared", Toast.LENGTH_SHORT).show()
        }
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryTypeFilter(filter: String?) {
        _historyTypeFilter.value = filter
    }

    fun saveApiConfig(newConfig: ApiConfig) {
        settingsRepo.saveConfig(newConfig)
        Toast.makeText(getApplication(), "Settings saved successfully!", Toast.LENGTH_SHORT).show()
    }

    fun resetApiConfig() {
        settingsRepo.resetToDefaults()
        Toast.makeText(getApplication(), "Settings reset to defaults", Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val MASTER_PASSWORD = "Decode@0000"
    }

    fun unlockApp(password: String): Boolean {
        if (password == MASTER_PASSWORD) {
            _isUnlocked.value = true
            _unlockError.value = null
            return true
        } else {
            _unlockError.value = "Incorrect password! Access denied."
            return false
        }
    }

    fun clearUnlockError() {
        _unlockError.value = null
    }

    fun lockApp() {
        _isUnlocked.value = false
        _unlockError.value = null
    }

    fun copyToClipboard(text: String, label: String = "Copied Text") {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "$label copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    fun shareContent(content: String, title: String = "Share Info") {
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, content)
            putExtra(Intent.EXTRA_TITLE, title)
            type = "text/plain"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val shareIntent = Intent.createChooser(sendIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(shareIntent)
    }
}
