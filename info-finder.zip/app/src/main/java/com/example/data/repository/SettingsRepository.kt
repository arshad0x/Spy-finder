package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.ApiConfig
import com.example.data.model.DEFAULT_HTML_TEMPLATE
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("info_finder_prefs", Context.MODE_PRIVATE)

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<ApiConfig> = _configFlow.asStateFlow()

    private fun loadConfig(): ApiConfig {
        return ApiConfig(
            numberApiUrl = prefs.getString("num_api_url", "https://anon-num-info.vercel.app/num") ?: "https://anon-num-info.vercel.app/num",
            numberApiKey = prefs.getString("num_api_key", "temp2808num") ?: "temp2808num",
            numberParamName = prefs.getString("num_param_name", "num") ?: "num",
            vehicleApiUrl = prefs.getString("veh_api_url", "https://anon-num-info.vercel.app/num") ?: "https://anon-num-info.vercel.app/num",
            vehicleApiKey = prefs.getString("veh_api_key", "temp2808num") ?: "temp2808num",
            vehicleParamName = prefs.getString("veh_param_name", "num") ?: "num",
            customHtmlTemplate = prefs.getString("custom_html_template", DEFAULT_HTML_TEMPLATE) ?: DEFAULT_HTML_TEMPLATE
        )
    }

    fun saveConfig(config: ApiConfig) {
        prefs.edit()
            .putString("num_api_url", config.numberApiUrl)
            .putString("num_api_key", config.numberApiKey)
            .putString("num_param_name", config.numberParamName)
            .putString("veh_api_url", config.vehicleApiUrl)
            .putString("veh_api_key", config.vehicleApiKey)
            .putString("veh_param_name", config.vehicleParamName)
            .putString("custom_html_template", config.customHtmlTemplate)
            .apply()
        _configFlow.value = config
    }

    fun resetToDefaults() {
        val defaultConfig = ApiConfig()
        saveConfig(defaultConfig)
    }
}
