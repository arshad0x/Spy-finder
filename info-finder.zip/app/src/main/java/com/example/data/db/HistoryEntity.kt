package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lookup_history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // NUMBER or VEHICLE
    val query: String,
    val isSuccess: Boolean,
    val statusCode: Int,
    val summaryTitle: String,
    val rawResponse: String,
    val parsedDataJson: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
