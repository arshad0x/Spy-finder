package com.example.data.api

import com.example.data.model.ApiConfig
import com.example.data.model.LookupResult
import com.example.data.model.LookupType
import com.example.util.HtmlTemplateEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

class InfoApiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {

    suspend fun performLookup(
        type: LookupType,
        query: String,
        config: ApiConfig
    ): LookupResult = withContext(Dispatchers.IO) {
        val trimmedQuery = query.trim()
        val baseUrlStr = when (type) {
            LookupType.NUMBER -> config.numberApiUrl.trim()
            LookupType.VEHICLE -> config.vehicleApiUrl.trim()
        }
        val apiKey = when (type) {
            LookupType.NUMBER -> config.numberApiKey.trim()
            LookupType.VEHICLE -> config.vehicleApiKey.trim()
        }
        val paramName = when (type) {
            LookupType.NUMBER -> config.numberParamName.trim()
            LookupType.VEHICLE -> config.vehicleParamName.trim()
        }

        // Build target URL
        val targetUrl = buildUrl(baseUrlStr, apiKey, paramName, trimmedQuery)

        try {
            val request = Request.Builder()
                .url(targetUrl)
                .addHeader("User-Agent", "InfoFinderApp/1.0 (Android)")
                .addHeader("Accept", "application/json, text/plain, */*")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val statusCode = response.code
                val responseBody = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val parsed = HtmlTemplateEngine.parseJsonToMap(responseBody)
                    val result = LookupResult(
                        query = trimmedQuery,
                        type = type,
                        isSuccess = true,
                        statusCode = statusCode,
                        rawResponse = responseBody,
                        parsedData = parsed,
                        timestamp = System.currentTimeMillis()
                    )
                    val html = HtmlTemplateEngine.renderHtml(result, config.customHtmlTemplate)
                    result.copy(generatedHtml = html)
                } else {
                    val parsed = HtmlTemplateEngine.parseJsonToMap(responseBody)
                    val errorMsg = "HTTP $statusCode: ${response.message.ifBlank { "Error received from server" }}"
                    val result = LookupResult(
                        query = trimmedQuery,
                        type = type,
                        isSuccess = false,
                        statusCode = statusCode,
                        rawResponse = responseBody,
                        parsedData = parsed,
                        errorMessage = errorMsg,
                        timestamp = System.currentTimeMillis()
                    )
                    val html = HtmlTemplateEngine.renderHtml(result, config.customHtmlTemplate)
                    result.copy(generatedHtml = html)
                }
            }
        } catch (e: IOException) {
            val result = LookupResult(
                query = trimmedQuery,
                type = type,
                isSuccess = false,
                statusCode = 0,
                rawResponse = "",
                errorMessage = "Network connection error: ${e.localizedMessage ?: "Unable to reach server"}",
                timestamp = System.currentTimeMillis()
            )
            val html = HtmlTemplateEngine.renderHtml(result, config.customHtmlTemplate)
            result.copy(generatedHtml = html)
        } catch (e: Exception) {
            val result = LookupResult(
                query = trimmedQuery,
                type = type,
                isSuccess = false,
                statusCode = 0,
                rawResponse = "",
                errorMessage = "Error: ${e.localizedMessage ?: "Unexpected error"}",
                timestamp = System.currentTimeMillis()
            )
            val html = HtmlTemplateEngine.renderHtml(result, config.customHtmlTemplate)
            result.copy(generatedHtml = html)
        }
    }

    private fun buildUrl(
        baseUrlStr: String,
        apiKey: String,
        paramName: String,
        query: String
    ): String {
        // If the URL already has placeholder like {num} or {query}
        if (baseUrlStr.contains("{query}") || baseUrlStr.contains("{num}") || baseUrlStr.contains("{rc}")) {
            return baseUrlStr
                .replace("{query}", query)
                .replace("{num}", query)
                .replace("{rc}", query)
                .replace("{key}", apiKey)
        }

        // Try parsing as HttpUrl
        val parsedHttpUrl = baseUrlStr.toHttpUrlOrNull()
        if (parsedHttpUrl != null) {
            val builder = parsedHttpUrl.newBuilder()
            if (apiKey.isNotBlank() && !baseUrlStr.contains("key=")) {
                builder.addQueryParameter("key", apiKey)
            }
            if (paramName.isNotBlank() && !baseUrlStr.contains("$paramName=")) {
                builder.addQueryParameter(paramName, query)
            } else if (baseUrlStr.endsWith("=") || baseUrlStr.endsWith("&")) {
                return baseUrlStr + query
            }
            return builder.build().toString()
        }

        // Fallback simple string concatenation
        val separator = if (baseUrlStr.contains("?")) "&" else "?"
        val keyPart = if (apiKey.isNotBlank() && !baseUrlStr.contains("key=")) "key=$apiKey&" else ""
        return "$baseUrlStr$separator$keyPart$paramName=$query"
    }
}
