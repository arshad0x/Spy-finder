package com.example.data.model

enum class LookupType(val displayName: String) {
    NUMBER("Number to Info"),
    VEHICLE("Vehicle to Info")
}

data class ApiConfig(
    val numberApiUrl: String = "https://anon-num-info.vercel.app/num",
    val numberApiKey: String = "temp2808num",
    val numberParamName: String = "num",
    val vehicleApiUrl: String = "https://anon-num-info.vercel.app/num", // Configurable live endpoint
    val vehicleApiKey: String = "temp2808num",
    val vehicleParamName: String = "num",
    val customHtmlTemplate: String = DEFAULT_HTML_TEMPLATE
)

data class LookupResult(
    val query: String,
    val type: LookupType,
    val isSuccess: Boolean,
    val statusCode: Int = 200,
    val rawResponse: String = "",
    val parsedData: Map<String, String> = emptyMap(),
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val generatedHtml: String = ""
)

const val DEFAULT_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lookup Report - {{QUERY}}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: #0b111e; color: #f1f5f9; padding: 18px; line-height: 1.5; }
        .header { background: linear-gradient(135deg, #1e293b, #0f172a); border: 1px solid #334155; border-radius: 16px; padding: 20px; margin-bottom: 18px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; background: rgba(0, 229, 255, 0.15); color: #00e5ff; border: 1px solid rgba(0, 229, 255, 0.4); margin-bottom: 10px; }
        .title { font-size: 22px; font-weight: 800; color: #ffffff; margin-bottom: 4px; word-break: break-all; }
        .subtitle { font-size: 13px; color: #94a3b8; }
        .card { background: #131d31; border: 1px solid #1e2e4a; border-radius: 14px; padding: 16px; margin-bottom: 14px; }
        .card-title { font-size: 14px; font-weight: 700; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; border-bottom: 1px solid #1e2e4a; padding-bottom: 8px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; }
        .item { background: #19253d; padding: 10px 12px; border-radius: 10px; border: 1px solid #233554; }
        .item-label { font-size: 11px; color: #94a3b8; text-transform: capitalize; margin-bottom: 4px; }
        .item-value { font-size: 13px; font-weight: 600; color: #f8fafc; word-break: break-word; }
        .raw-box { background: #070c14; border: 1px solid #1e293b; border-radius: 10px; padding: 12px; font-family: monospace; font-size: 12px; color: #38bdf8; overflow-x: auto; white-space: pre-wrap; word-break: break-all; max-height: 250px; }
        .footer { text-align: center; font-size: 11px; color: #64748b; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="badge">{{TYPE}}</div>
        <div class="title">{{QUERY}}</div>
        <div class="subtitle">Generated on {{DATE}} &bull; Status: {{STATUS}}</div>
    </div>

    <div class="card">
        <div class="card-title">Extracted Information</div>
        <div class="grid">
            {{DATA_ITEMS}}
        </div>
    </div>

    <div class="card">
        <div class="card-title">Raw Response Data</div>
        <div class="raw-box">{{RAW_JSON}}</div>
    </div>

    <div class="footer">
        Verified Lookup Report &bull; Info Finder System
    </div>
</body>
</html>
"""
