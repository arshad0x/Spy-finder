package com.example.util

import com.example.data.model.DEFAULT_HTML_TEMPLATE
import com.example.data.model.LookupResult
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object HtmlTemplateEngine {

    private val dateFormatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    fun renderHtml(
        result: LookupResult,
        customTemplate: String = DEFAULT_HTML_TEMPLATE
    ): String {
        val template = if (customTemplate.isBlank()) DEFAULT_HTML_TEMPLATE else customTemplate

        val dateStr = dateFormatter.format(Date(result.timestamp))
        val statusStr = if (result.isSuccess) "Success (HTTP ${result.statusCode})" else "Error"

        // Build data items HTML
        val itemsHtml = StringBuilder()
        if (result.parsedData.isNotEmpty()) {
            for ((key, value) in result.parsedData) {
                itemsHtml.append("""
                    <div class="item">
                        <div class="item-label">${escapeHtml(key.replace("_", " "))}</div>
                        <div class="item-value">${escapeHtml(value)}</div>
                    </div>
                """.trimIndent())
            }
        } else {
            itemsHtml.append("""
                <div class="item" style="grid-column: 1 / -1;">
                    <div class="item-label">Status</div>
                    <div class="item-value">${escapeHtml(if (result.isSuccess) "No structured fields found in response" else (result.errorMessage ?: "Failed to fetch"))}</div>
                </div>
            """.trimIndent())
        }

        val rawEscaped = escapeHtml(result.rawResponse.ifBlank { result.errorMessage ?: "Empty Response" })

        var rendered = template
            .replace("{{QUERY}}", escapeHtml(result.query))
            .replace("{{TYPE}}", escapeHtml(result.type.displayName))
            .replace("{{DATE}}", dateStr)
            .replace("{{STATUS}}", statusStr)
            .replace("{{DATA_ITEMS}}", itemsHtml.toString())
            .replace("{{RAW_JSON}}", rawEscaped)

        // Also replace direct keys like {{name}}, {{mobile}}, {{operator}}, etc.
        for ((key, value) in result.parsedData) {
            rendered = rendered.replace("{{${key.lowercase()}}}", escapeHtml(value))
            rendered = rendered.replace("{{${key.uppercase()}}}", escapeHtml(value))
            rendered = rendered.replace("{{$key}}", escapeHtml(value))
        }

        return rendered
    }

    fun parseJsonToMap(jsonString: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val trimmed = jsonString.trim()
        if (trimmed.isEmpty()) return result

        try {
            if (trimmed.startsWith("{")) {
                val jsonObject = JSONObject(trimmed)
                flattenJsonObject("", jsonObject, result)
            } else if (trimmed.startsWith("[")) {
                val jsonArray = JSONArray(trimmed)
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.opt(i)
                    if (item is JSONObject) {
                        flattenJsonObject("item_${i + 1}", item, result)
                    } else if (item != null) {
                        result["Item ${i + 1}"] = item.toString()
                    }
                }
            } else {
                // Key-value lines or plain text
                val lines = trimmed.lines()
                for (line in lines) {
                    val parts = line.split(":", limit = 2)
                    if (parts.size == 2) {
                        result[parts[0].trim()] = parts[1].trim()
                    } else if (line.isNotBlank()) {
                        result["Info"] = line.trim()
                    }
                }
            }
        } catch (_: Exception) {
            // Fallback key-value extraction from plain string
            val lines = trimmed.lines()
            for (line in lines) {
                val parts = line.split(":", limit = 2)
                if (parts.size == 2) {
                    result[parts[0].trim()] = parts[1].trim()
                }
            }
        }
        return result
    }

    private fun flattenJsonObject(prefix: String, jsonObject: JSONObject, outMap: MutableMap<String, String>) {
        val keys = jsonObject.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = jsonObject.opt(key)
            val fullKey = if (prefix.isEmpty()) key else "${prefix}_$key"

            when (value) {
                is JSONObject -> flattenJsonObject(fullKey, value, outMap)
                is JSONArray -> {
                    if (value.length() == 0) {
                        outMap[fullKey] = "[]"
                    } else {
                        val stringList = mutableListOf<String>()
                        for (i in 0 until value.length()) {
                            val arrayItem = value.opt(i)
                            if (arrayItem is JSONObject) {
                                flattenJsonObject("${fullKey}_${i + 1}", arrayItem, outMap)
                            } else if (arrayItem != null) {
                                stringList.add(arrayItem.toString())
                            }
                        }
                        if (stringList.isNotEmpty()) {
                            outMap[fullKey] = stringList.joinToString(", ")
                        }
                    }
                }
                null, JSONObject.NULL -> {
                    outMap[fullKey] = "N/A"
                }
                else -> {
                    outMap[fullKey] = value.toString()
                }
            }
        }
    }

    private fun escapeHtml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")
    }
}
